"""Run all three sort benchmarks on the same seeded 100,000-item list."""

import argparse
import csv
from pathlib import Path
import platform
import random
import sys

from benchmark import benchmark_sort, print_results
from sorting_algorithms import quick_sort, merge_sort, heap_sort


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--size", type=int, default=100_000,
                        help="number of integers to sort (default: 100000)")
    parser.add_argument("--iterations", type=int, default=5,
                        help="timing runs per algorithm (default: 5)")
    parser.add_argument("--seed", type=int, default=660,
                        help="random seed used to create one shared dataset")
    parser.add_argument("--output", default="benchmark_results.csv",
                        help="path for CSV output")
    args = parser.parse_args()
    if args.size < 1 or args.iterations < 1:
        parser.error("--size and --iterations must both be positive")

    generator = random.Random(args.seed)
    data = [generator.randint(-1_000_000, 1_000_000)
            for _ in range(args.size)]
    print(f"Python: {sys.version.split()[0]} | Platform: {platform.platform()}")
    print(f"Dataset: {len(data):,} integers | seed={args.seed} "
          f"| iterations={args.iterations}")
    print("Time is measured without tracemalloc; memory is measured in "
          "a separate instrumented run.\n")

    results = [
        benchmark_sort(function, data, iterations=args.iterations, name=label)
        for label, function in [
            ("Quick sort", quick_sort),
            ("Merge sort", merge_sort),
            ("Heap sort", heap_sort),
        ]
    ]
    print_results(results)

    csv_path = Path(args.output)
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["algorithm", "items", "iterations", "average_ms",
                         "median_ms", "peak_traced_mb", "under_400_ms",
                         "traced_under_50_mb"])
        for result in results:
            writer.writerow([result.algorithm, result.items,
                             result.iterations, f"{result.average_ms:.3f}",
                             f"{result.median_ms:.3f}",
                             f"{result.peak_traced_mb:.6f}",
                             result.average_ms < 400,
                             result.peak_traced_mb < 50])
    print(f"\nSaved results to {csv_path.resolve()}")


if __name__ == "__main__":
    main()
