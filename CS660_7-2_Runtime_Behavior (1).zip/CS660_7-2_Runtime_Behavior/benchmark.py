"""Reusable sort benchmark: independent timing and tracemalloc trials.

Timing trials exclude copying the input and exclude tracemalloc overhead.
Peak traced memory measures allocations made during a *separate* sort;
it is NOT the total resident memory (RSS) of the Python process.
"""

from dataclasses import dataclass
from collections.abc import Callable
import statistics
import time
import tracemalloc

SortFunction = Callable[[list[int]], list[int] | None]


@dataclass(frozen=True)
class BenchmarkResult:
    algorithm: str
    items: int
    iterations: int
    average_ms: float
    median_ms: float
    peak_traced_mb: float


def benchmark_sort(
    sort_function: SortFunction,
    input_list: list[int],
    iterations: int = 5,
    *,
    name: str | None = None,
) -> BenchmarkResult:
    """Time a user-supplied sort repeatedly and profile peak traced memory.

    The input is copied for each iteration. Sorts may mutate and/or return
    the list; both are supported. Results are validated for correctness.
    """
    if iterations < 1:
        raise ValueError("iterations must be one or greater")

    expected = sorted(input_list)  # Validation only, never timed.
    timings_ms: list[float] = []

    for _ in range(iterations):
        working = input_list.copy()  # Do not time data preparation.
        start = time.perf_counter()
        returned = sort_function(working)
        elapsed_ms = (time.perf_counter() - start) * 1000
        result_list = working if returned is None else returned
        if result_list != expected:
            raise AssertionError(f"{sort_function.__name__} returned incorrect output")
        timings_ms.append(elapsed_ms)

    working = input_list.copy()
    tracemalloc.start()
    try:
        returned = sort_function(working)
        _, peak_bytes = tracemalloc.get_traced_memory()
    finally:
        tracemalloc.stop()
    result_list = working if returned is None else returned
    if result_list != expected:
        raise AssertionError("Memory-profiling run returned incorrect output")

    return BenchmarkResult(
        algorithm=name or sort_function.__name__,
        items=len(input_list),
        iterations=iterations,
        average_ms=statistics.mean(timings_ms),
        median_ms=statistics.median(timings_ms),
        peak_traced_mb=peak_bytes / 1_000_000,
    )


def print_results(results: list[BenchmarkResult]) -> None:
    """Print a compact report against the case-study targets."""
    print(f"{'Algorithm':<13} {'Avg time (ms)':>14} {'Median (ms)':>13} "
          f"{'Peak traced MB':>15} {'Time <400':>11} {'Traced <50':>12}")
    print("-" * 84)
    for result in results:
        time_pass = "PASS" if result.average_ms < 400 else "FAIL"
        memory_pass = "PASS" if result.peak_traced_mb < 50 else "FAIL"
        print(f"{result.algorithm:<13} {result.average_ms:>14.2f} "
              f"{result.median_ms:>13.2f} {result.peak_traced_mb:>15.3f} "
              f"{time_pass:>11} {memory_pass:>12}")
    print("\nNote: Peak *traced* memory is not total process RAM usage; "
          "a full-RSS check is needed to certify the 50-MB total-memory target.")
