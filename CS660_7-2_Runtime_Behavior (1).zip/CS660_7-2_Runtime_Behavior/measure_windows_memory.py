"""Check peak total-process memory for each sort on Windows."""

import ctypes
from ctypes import wintypes
import random
import subprocess
import sys
from sorting_algorithms import quick_sort, merge_sort, heap_sort


class MemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def peak_memory_mb():
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    psapi.GetProcessMemoryInfo.argtypes = [
        wintypes.HANDLE, ctypes.POINTER(MemoryCounters), wintypes.DWORD
    ]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    counts = MemoryCounters()
    counts.cb = ctypes.sizeof(counts)
    if not psapi.GetProcessMemoryInfo(
        kernel32.GetCurrentProcess(), ctypes.byref(counts), counts.cb
    ):
        raise ctypes.WinError(ctypes.get_last_error())
    return counts.PeakWorkingSetSize / 1_000_000


if __name__ == "__main__":
    if len(sys.argv) == 2:
        functions = {"quick": quick_sort, "merge": merge_sort, "heap": heap_sort}
        rng = random.Random(660)
        numbers = [rng.randint(-1_000_000, 1_000_000) for _ in range(100_000)]
        functions[sys.argv[1]](numbers)
        print(f"{peak_memory_mb():.2f}")
    else:
        for name in ("quick", "merge", "heap"):
            result = subprocess.run(
                [sys.executable, __file__, name], text=True,
                capture_output=True, check=True
            )
            memory_mb = float(result.stdout.strip())
            status = "PASS" if memory_mb < 50 else "FAIL"
            print(f"{name.title():<6} sort: {memory_mb:.2f} MB  {status}")
