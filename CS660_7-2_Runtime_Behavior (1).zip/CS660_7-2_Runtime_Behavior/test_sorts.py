"""Correctness and benchmark-harness checks (stdlib unittest)."""

import random
import unittest

from benchmark import benchmark_sort
from sorting_algorithms import quick_sort, merge_sort, heap_sort


class SortingTests(unittest.TestCase):
    def test_algorithms_on_edge_cases(self):
        cases = [[], [7], [2, 1], [3, 3, 3, 3],
                 [1, 2, 3, 4, 5], [5, 4, 3, 2, 1],
                 [0, -2, 50, -2, 7, 3]]
        for algorithm in [quick_sort, merge_sort, heap_sort]:
            for case in cases:
                with self.subTest(algorithm=algorithm.__name__, case=case):
                    values = case.copy()
                    returned = algorithm(values)
                    self.assertIs(returned, values)
                    self.assertEqual(values, sorted(case))

    def test_randomized_lists(self):
        randomizer = random.Random(42)
        for length in [10, 99, 1000]:
            case = [randomizer.randint(-50, 50) for _ in range(length)]
            for algorithm in [quick_sort, merge_sort, heap_sort]:
                with self.subTest(algorithm=algorithm.__name__, length=length):
                    self.assertEqual(algorithm(case.copy()), sorted(case))

    def test_benchmark_preserves_input(self):
        original = [4, 1, 3, 2]
        output = benchmark_sort(heap_sort, original, iterations=2)
        self.assertEqual(original, [4, 1, 3, 2])
        self.assertEqual(output.items, 4)
        self.assertEqual(output.iterations, 2)
        self.assertGreaterEqual(output.average_ms, 0)
        self.assertGreaterEqual(output.peak_traced_mb, 0)

    def test_iterations_validation(self):
        with self.assertRaises(ValueError):
            benchmark_sort(quick_sort, [2, 1], iterations=0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
