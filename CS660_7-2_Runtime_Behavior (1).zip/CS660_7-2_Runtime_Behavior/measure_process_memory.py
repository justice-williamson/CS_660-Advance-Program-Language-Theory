"""Optional POSIX check of peak total-process memory per sorting algorithm.

Each algorithm runs in its own Python process so its ru_maxrss high-water
mark is not influenced by the other sorting algorithms. This supplements,
but does not replace, the required tracemalloc measurement in benchmark.py.
Run: python measure_process_memory.py
"""

import json
import platform
import random
import subprocess
import sys


def child_main(algorithm_name: str) -> None:
    import resource  # Available on Linux / macOS, not on Windows.
    from sorting_algorithms import quick_sort, merge_sort, heap_sort

    algorithms = {"quick": quick_sort, "merge": merge_sort, "heap": heap_sort}
    generator = random.Random(660)
    data = [generator.randint(-1_000_000, 1_000_000) for _ in range(100_000)]
    algorithms[algorithm_name](data)
    # Linux reports KiB; macOS reports bytes.
    peak_raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    peak_mb = peak_raw / (1_000_000 if sys.platform == "darwin" else (1_000_000 / 1024))
    print(json.dumps({"algorithm": algorithm_name, "peak_rss_mb": peak_mb}))


def main() -> None:
    if sys.platform not in {"linux", "darwin"}:
        print("This supplementary resource-based RSS check requires Linux/macOS.")
        return
    lean = "--lean-runtime" in sys.argv
    print(f"Peak total-process RSS, separate processes | {platform.platform()}")
    print("Python start:", "-S (skip site initialization)" if lean else "default")
    for name in ["quick", "merge", "heap"]:
        run = subprocess.run(
            [sys.executable] + (["-S"] if lean else []) + [__file__, "--child", name],
            capture_output=True, text=True, check=True,
        )
        sample = json.loads(run.stdout)
        status = "PASS" if sample["peak_rss_mb"] < 50 else "FAIL"
        print(f"{name.title():<8}: {sample['peak_rss_mb']:6.2f} MB   (<50 MB: {status})")
    print("RSS includes the interpreter and input data; recheck on target hardware.")


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--child":
        child_main(sys.argv[2])
    else:
        main()
