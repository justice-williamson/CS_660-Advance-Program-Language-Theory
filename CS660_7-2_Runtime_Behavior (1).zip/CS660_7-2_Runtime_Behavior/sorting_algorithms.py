"""Three in-place sorting algorithms for CS 660 Module Seven.

Each function accepts a list of integers, changes that list in place,
and returns the same list. The algorithms do not use list.sort() or sorted().
"""


def quick_sort(numbers: list[int]) -> list[int]:
    """Sort in place using iterative three-way quicksort.

    Median-of-three pivot selection and a three-way partition handle
    already sorted inputs and repeated values more gracefully.
    """
    stack = [(0, len(numbers) - 1)]

    while stack:
        left, right = stack.pop()
        while left < right:
            middle = (left + right) // 2
            a, b, c = numbers[left], numbers[middle], numbers[right]
            pivot = max(min(a, b), min(max(a, b), c))

            lower, index, upper = left, left, right
            while index <= upper:
                if numbers[index] < pivot:
                    numbers[lower], numbers[index] = numbers[index], numbers[lower]
                    lower += 1
                    index += 1
                elif numbers[index] > pivot:
                    numbers[index], numbers[upper] = numbers[upper], numbers[index]
                    upper -= 1
                else:
                    index += 1

            # Process the smaller partition now to keep stack size small.
            if lower - left < right - upper:
                if upper + 1 < right:
                    stack.append((upper + 1, right))
                right = lower - 1
            else:
                if left < lower - 1:
                    stack.append((left, lower - 1))
                left = upper + 1

    return numbers


def merge_sort(numbers: list[int]) -> list[int]:
    """Sort in place with bottom-up, iterative merge sort."""
    length = len(numbers)
    if length < 2:
        return numbers

    buffer = [0] * length
    width = 1
    source = numbers
    target = buffer

    while width < length:
        for start in range(0, length, 2 * width):
            middle = min(start + width, length)
            end = min(start + 2 * width, length)
            first, second, out = start, middle, start

            while first < middle and second < end:
                if source[first] <= source[second]:
                    target[out] = source[first]
                    first += 1
                else:
                    target[out] = source[second]
                    second += 1
                out += 1

            while first < middle:
                target[out] = source[first]
                first += 1
                out += 1
            while second < end:
                target[out] = source[second]
                second += 1
                out += 1

        source, target = target, source
        width *= 2

    if source is not numbers:
        numbers[:] = source
    return numbers


def heap_sort(numbers: list[int]) -> list[int]:
    """Sort in place by building and repeatedly shrinking a max heap."""
    length = len(numbers)

    def sift_down(root: int, end: int) -> None:
        """Move a root down until the max-heap property is restored."""
        while 2 * root + 1 <= end:
            child = 2 * root + 1
            if child + 1 <= end and numbers[child] < numbers[child + 1]:
                child += 1
            if numbers[root] >= numbers[child]:
                return
            numbers[root], numbers[child] = numbers[child], numbers[root]
            root = child

    for parent in range(length // 2 - 1, -1, -1):
        sift_down(parent, length - 1)

    for end in range(length - 1, 0, -1):
        numbers[0], numbers[end] = numbers[end], numbers[0]
        sift_down(0, end - 1)

    return numbers
