CS-660 | Module Seven | 7-2 Activity: Exploring Runtime Behavior Through Code
Student: Justice Williamson

PACKAGE CONTENTS
  sorting_algorithms.py          Quick sort, merge sort, and heap sort
  benchmark.py                   Reusable benchmark_sort(sort_function, input_list,
                                 iterations=5), using perf_counter + tracemalloc
  run_benchmarks.py              Command-line runner; prints results and saves CSV
  test_sorts.py                  Four unit tests for correctness and benchmarking
  measure_windows_memory.py     Windows peak process-working-set measurement
  measure_process_memory.py     Optional Linux/macOS process-memory check
  benchmark_results.csv         Actual Codio Windows benchmark measurements
  runtime_environment.txt       Actual Codio Windows environment and time results
  process_memory_results.txt    Actual Codio Windows full-process memory values
  unit_test_results.txt         Latest independent verification and Codio test record
  7-2 Activity- Exploring Runtime Behavior Through Code.docx
                                 Written report with results and analysis
  CS660_7-2_REPORT.txt   Plain-text report backup

HOW TO RUN (FROM THE FOLDER CONTAINING THE .py FILES)
  Windows / Codio (Python 3):
    python -m unittest -v test_sorts.py
    python run_benchmarks.py --size 100000 --iterations 5
    python measure_windows_memory.py

  Linux/macOS alternative for process-memory sampling:
    python measure_process_memory.py

  These scripts use Python standard-library modules only.
  Do not run the Linux/macOS memory script on Windows; it uses resource.
  No need to install additional packages to run the sorting benchmarks.

REUSING THE BENCHMARK
  Customize the dataset size, iterations, or seed:
    python run_benchmarks.py --size 10000 --iterations 3 --seed 660

  Or import the reusable module into your own Python script:
    from benchmark import benchmark_sort
    from sorting_algorithms import quick_sort
    result = benchmark_sort(quick_sort, [9, 1, 3], iterations=5)
    print(result)

RESULTS RECORDED FROM THE CODIO WINDOWS RUN (NOVEMBER 8, 2026)
  Environment: Python 3.13.3 | Windows Server 2022
  100,000 integers; seed=660; 5 timing iterations each
  Quick sort: 386.13 ms average; 18.19 MB peak working set — time PASS, memory PASS
  Merge sort: 339.29 ms average; 20.26 MB peak working set — time PASS, memory PASS
  Heap sort:  539.53 ms average; 18.79 MB peak working set — time FAIL, memory PASS
  All four Codio unit tests passed.

INTERPRETING THE MEMORY METRICS
  benchmark.py uses tracemalloc to measure peak Python allocations during a
  separate sorting call. That is NOT the same as whole-process RAM usage.
  measure_windows_memory.py instead reads the Windows process peak working set.
  Both are helpful but represent different measurements. Check the deployment
  environment before treating performance thresholds as guaranteed.

SUBMISSION
  The assignment asks for Python code and a Word document. The included Word
  document is named "7-2 Activity- Exploring Runtime Behavior Through Code.docx".
  The Python source files and this document can be submitted as directed by SNHU.
